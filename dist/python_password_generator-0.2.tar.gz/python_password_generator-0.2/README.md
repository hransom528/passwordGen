# python-password-generator
Generates a random password using python.

For instructions on how to install, read the corresponding file in the "HOW TO INSTALL" directory of this repository for your OS.
You can also use setup.py for installing this using PiP.

Any questions or issues, email me at hransom528@gmail.com
Happy Coding!
